The Lego ASM Language Compiler v1.0
Last Updated March 14, 2001
Written by Jason Gilder, Mike Peterson, and Jason Wright
Copyright (c) 2001 Wright State University

http://birg.cs.wright.edu/legoASM.html

